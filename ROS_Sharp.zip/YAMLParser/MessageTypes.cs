﻿#region USINGZ

using System;
using System.Collections.Generic;

#endregion

namespace FauxMessages
{
    public enum MsgTypes
    {
        Unknown,
        std_msgs__String,
        std_msgs__Header,
        std_msgs__Time,
        std_msgs__Duration,
        std_msgs__Byte
    }

    public enum SrvTypes
    {
        Unknown
    }
}
﻿namespace Messages.std_msgs
{
    internal class String
    {
        //placeholder
    }
}
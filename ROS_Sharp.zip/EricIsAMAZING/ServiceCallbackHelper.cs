﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ros_CSharp
{
    public class ServiceCallbackHelper<MReq, MRes> : IServiceCallbackHelper
    {
    }

    public class IServiceCallbackHelper
    {
    }
}

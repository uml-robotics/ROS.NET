﻿namespace XmlRpc_Wrapper
{
    public class AsyncXmlRpcConnection
    {

        public virtual void addToDispatch(XmlRpcDispatch disp)
        {
        }

        public virtual void removeFromDispatch(XmlRpcDispatch disp)
        {
        }

        public virtual bool check()
        {
            return false;
        }
    }
}